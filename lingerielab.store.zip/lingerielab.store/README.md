# Lingerie Lab

A PHP 8+/MySQL/Bootstrap 5 e-commerce starter for XAMPP.

## Setup

1. Start Apache and MySQL in XAMPP.
2. Open phpMyAdmin and import `database.sql`. The script creates the `lingerie_lab` database, tables, seed categories/products, payment methods, settings, and an admin account.
3. Visit `http://localhost/lingerielab.store/`.
4. Admin: `http://localhost/lingerielab.store/admin/login.php`
   - Email: `admin@lingerielab.store`
   - Password: `ChangeMe!2026`
5. Change the default admin password after first login by updating the account in MySQL or by adding a password-management screen before production use.

## Configuration

Database credentials live in `config/database.php` and default to XAMPP's `root` user with an empty password. Payment method details, shipping values, contact details, currency, and store settings are stored in MySQL and editable through the admin payment screen or settings table.

## Included working flows

- Responsive storefront, catalog search/filtering, product detail, size guide, cart, session quantities, checkout, order creation, order tracking, registration, login, account history, contact form, newsletter capture, policies, WhatsApp contact, and SEO files.
- Home page shows four pieces from every category (28 products across 7 categories) inside a "Shop the collection" section, with category cards using matching local imagery.
- Protected admin login, dashboard metrics, product CRUD, category CRUD, order status/payment status updates, payment-method configuration, and contact message review.
- PDO prepared statements, password hashing, CSRF tokens on state-changing forms, output escaping, session auth, security headers, and disabled directory indexes.

## Sizes and colours (variants)

Products are sized by **bra band + cup**, not letter sizes. `includes/variants.php` is the single source of truth and is auto-loaded by `includes/functions.php`:

- `size_chart()` - bands 32-50 mapped to the stocked cups, e.g. `32AA, 32A, 32B, 32C, 32D, 32DD/E, 32DDD/F, 32G` up to `50B ... 50H` (75 sizes in total).
- `size_groups($csv)` - regroups a product's stored CSV into `[band => cups]` so the storefront can render one row per band.
- `size_csv(array $picked)` - turns submitted checkboxes into a de-duplicated, chart-ordered CSV; this is the value stored in `products.sizes`.
- `color_palette()` - the 15 core shades (`Black, White, Ivory, Nude, Blush Pink, Red, Wine, Navy, Royal Blue, Emerald, Teal, Purple, Charcoal, Chocolate, Peach`) with their hex values.
- `color_csv(array $picked, string $custom)` / `color_list()` / `product_colors()` - validate and order the shades stored in `products.colors`. Palette shades are listed first, then any custom shades the admin typed.
- `color_hex($name)` - resolves a swatch colour, falling back to `shade_hex()` (Lilac, Coral, Sunset, Burgundy, Midnight, Rose, Cream and more) and finally to a neutral grey.

### Storefront

`product.php` renders one chip per cup inside a row per band (`Band 32`, `Band 34`, ...) plus a colour swatch chip per shade, replacing the old letter-size buttons and colour dropdown. Bands and cups flow through the cart unchanged because `cart.php` stores the chosen size and colour as plain strings, and both the bag and the checkout order summary print the chosen `size · colour` under each product name. `cart.php` re-validates every submitted size and colour against the product's stored lists, so a stale or hand-crafted request is refused (an AJAX add returns `{"success":false,"message":"That size or colour is not available."}`).

### Admin

`admin/product-edit.php` shows the full 75-size chart grouped by band with:

- a **Band checkbox** that ticks or clears every cup in that band,
- a **Common range** button that jumps to the 20 best-selling sizes (`core_sizes()`, bands 32-40 in cups B, C, D and DD/E) - the same range a brand-new product starts with,
- **Select all** / **Clear all** buttons,
- a live **"n of 75 sizes selected"** counter,
- the 15-shade palette as swatch chips, plus an **extra shades** field for colours outside the palette.

`admin/includes/footer.php` loads `assets/js/admin-variants.js` for the band toggles and counter, `admin/products.php` lists a size count and colour swatches per product, and `size-guide.php` documents the same band/cup chart.

`products.sizes` and `products.colors` are `VARCHAR(1000)` (a full 75-size chart is roughly 370 characters). Any sizes without a list fall back to a hidden field plus a "message us to confirm your size" note on the product page. The original letter sizes were migrated to band/cup equivalents and `database.sql` seeds the converted values, so a fresh import matches the live store.


## Before production

Configure HTTPS, SMTP/email delivery, real payment instructions, upload storage outside the public web root, backups, rate limiting, and a production database user with a strong password. Replace the bundled seed imagery with optimized product photography or admin-uploaded images.

## Image assets

All storefront imagery is stored locally, so the site renders without external image requests:

- `assets/images/categories/` - one photo per category, named after the category slug (`bras.jpg`, `panties.jpg`, `lingerie-sets.jpg`, `nightwear.jpg`, `shapewear.jpg`, `sports-bras.jpg`, `bikinis.jpg`). `categories.image` stores these paths.
- `assets/images/products/` - one photo per product, named after the product slug. `products.image` stores these paths.
- `assets/images/product-default.jpg` - fallback used by `product_image()` when a row has no image.
- `banner.png` (project root) - hero banner referenced by `assets/css/hero-banner.css`.

The seed photos are free-to-use stock images (Pexels) of lingerie, swimwear and model photography. Swap in your own licensed photography before launch and keep the same file names, or update the `image` columns in MySQL after uploading.
