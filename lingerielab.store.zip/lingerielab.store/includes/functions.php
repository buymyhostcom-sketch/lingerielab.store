<?php
declare(strict_types=1);
require_once __DIR__.'/variants.php';
require_once __DIR__.'/../config/paths.php';
require_once __DIR__.'/../config/database.php';
function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); }
/* Resolve a path relative to the assets directory (e.g. "css/style.css") to a full URL. */
function asset(string $path): string { return preg_match('#^(https?:)?//#i', $path) ? $path : ASSETS_URL.ltrim($path, '/'); }
/* Same, but for values stored in the database that are relative to the site root. */
function site_asset(string $path): string { return preg_match('#^(https?:)?//#i', $path) ? $path : SITE_URL.ltrim($path, '/'); }
function redirect(string $url): never { header('Location: '.$url); exit; }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">'; }
function verify_csrf(): void { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Invalid request token.'); } }
function setting(string $key, string $fallback=''): string { global $pdo; static $cache=[]; if (!array_key_exists($key,$cache)) { $s=$pdo->prepare('SELECT setting_value FROM settings WHERE setting_key=?'); $s->execute([$key]); $cache[$key]=(string)($s->fetchColumn() ?? $fallback); } return $cache[$key]; }
function current_user(): ?array { global $pdo; if (empty($_SESSION['user_id'])) return null; $s=$pdo->prepare('SELECT * FROM users WHERE id=? AND status=1'); $s->execute([$_SESSION['user_id']]); return $s->fetch() ?: null; }
function require_login(): void { if (!current_user()) redirect('login.php'); }
function cart_count(): int { return array_sum(array_column($_SESSION['cart'] ?? [], 'quantity')); }
function cart_items(): array { global $pdo; $cart=$_SESSION['cart'] ?? []; if (!$cart) return []; $ids=array_values(array_unique(array_column($cart,'product_id'))); $marks=implode(',',array_fill(0,count($ids),'?')); $s=$pdo->prepare("SELECT * FROM products WHERE id IN ($marks) AND status=1"); $s->execute($ids); $out=[]; foreach ($s as $p) { foreach ($cart as $key=>$item) { if ((int)$item['product_id'] !== (int)$p['id']) continue; $p['cart_key']=$key; $p['quantity']=$item['quantity']; $p['size']=$item['size']; $p['color']=$item['color']; $p['line_total']=($p['sale_price'] ?: $p['price'])*$p['quantity']; $out[]=$p; } } return $out; }
function cart_total(): float { return (float)array_sum(array_column(cart_items(),'line_total')); }
function price(array $p): string { return e(setting('currency','Rs.')).' '.number_format((float)($p['sale_price'] ?: $p['price'])); }
function product_image(?string $image): string { return e(site_asset($image ?: 'assets/images/product-default.jpg')); }
function admin_required(): void { if (empty($_SESSION['admin_id'])) redirect('login.php'); }
