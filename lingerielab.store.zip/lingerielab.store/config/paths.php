<?php
declare(strict_types=1);

/*
 * Base URLs.
 *
 * The storefront lives on the apex domain and the admin panel is served from
 * the admin. subdomain, so relative URLs such as "../assets/css/style.css"
 * escape the subdomain's document root and 404. Every cross-directory link
 * therefore goes through these constants instead.
 *
 * The values are derived from the current Host header, which keeps the same
 * code correct on XAMPP (localhost), on the apex domain and on the subdomain.
 */

if (!defined('SITE_SCHEME')) {
    $https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (int)($_SERVER['SERVER_PORT'] ?? 0) === 443;
    define('SITE_SCHEME', $https ? 'https' : 'http');
}

if (!defined('SITE_HOST')) {
    $host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
    $host = preg_replace('/:\d+$/', '', $host);   // drop any non-standard port
    $host = preg_replace('/^www\./i', '', $host);  // canonicalise the apex
    $host = preg_match('/^admin\./i', $host) ? substr($host, 6) : $host;
    define('SITE_HOST', $host);
}

if (!defined('SITE_URL'))     define('SITE_URL', SITE_SCHEME.'://'.SITE_HOST.'/');
if (!defined('ADMIN_URL'))    define('ADMIN_URL', SITE_SCHEME.'://admin.'.SITE_HOST.'/');
if (!defined('ASSETS_URL'))   define('ASSETS_URL', SITE_URL.'assets/');
