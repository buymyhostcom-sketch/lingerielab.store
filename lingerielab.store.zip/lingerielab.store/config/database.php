<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

/*
 * Database credentials.
 *
 * Defaults suit XAMPP. On hosting the values come from the environment
 * (DB_HOST / DB_NAME / DB_USER / DB_PASS) so the production password never
 * has to be committed to the file that gets uploaded.
 */
const DB_HOST = '127.0.0.1';
const DB_NAME = 'lingerie_lab';
const DB_USER = 'root';
const DB_PASS = '';

$dbHost = (string)(getenv('DB_HOST') ?: DB_HOST);
$dbName = (string)(getenv('DB_NAME') ?: DB_NAME);
$dbUser = (string)(getenv('DB_USER') ?: DB_USER);
$dbPass = (string)(getenv('DB_PASS') ?: DB_PASS);

// Hosting hosts MySQL on a non-default port; honour it when supplied.
$dbPort = (int)(getenv('DB_PORT') ?: 0);
$dsn    = 'mysql:host='.$dbHost.($dbPort ? ';port='.$dbPort : '').';dbname='.$dbName.';charset=utf8mb4';

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]);
} catch (PDOException $e) {
    error_log('Database connection failed: '.$e->getMessage());
    http_response_code(500);
    exit('Database connection is unavailable. Import database.sql and check your MySQL settings.');
}
