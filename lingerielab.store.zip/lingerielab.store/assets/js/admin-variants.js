/* Admin variant pickers: whole-band toggles, select all/clear and a live size counter. */
function llVariantCounters() {
  var boxes = document.querySelectorAll('[data-band]');
  var out = document.querySelector('[data-size-count]');
  if (out) {
    var picked = 0;
    Array.prototype.forEach.call(boxes, function (box) { if (box.checked) picked++; });
    out.textContent = picked;
  }
}
function llVariantSyncBands() {
  Array.prototype.forEach.call(document.querySelectorAll('[data-band-toggle]'), function (toggle) {
    var cups = document.querySelectorAll('[data-band="' + toggle.dataset.bandToggle + '"]');
    var on = 0;
    Array.prototype.forEach.call(cups, function (cup) { if (cup.checked) on++; });
    toggle.checked = on > 0 && on === cups.length;
    toggle.indeterminate = on > 0 && on < cups.length;
  });
}
document.addEventListener('change', function (event) {
  var box = event.target;
  if (box.matches('[data-band-toggle]')) {
    Array.prototype.forEach.call(document.querySelectorAll('[data-band="' + box.dataset.bandToggle + '"]'), function (cup) { cup.checked = box.checked; });
  }
  if (box.matches('[data-band]') || box.matches('[data-band-toggle]')) {
    llVariantSyncBands();
    llVariantCounters();
  }
});
document.addEventListener('click', function (event) {
  var all = event.target.closest('[data-size-all]');
  var none = event.target.closest('[data-size-none]');
  var core = event.target.closest('[data-size-core]');
  if (!all && !none && !core) return;
  Array.prototype.forEach.call(document.querySelectorAll('[data-band]'), function (cup) {
    if (all) cup.checked = true;
    else if (none) cup.checked = false;
    else cup.checked = cup.hasAttribute('data-core');
  });
  llVariantSyncBands();
  llVariantCounters();
});
document.addEventListener('DOMContentLoaded', function () {
  llVariantSyncBands();
  llVariantCounters();
});
