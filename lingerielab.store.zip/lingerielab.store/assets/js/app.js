document.addEventListener('submit', function (event) {
  var form = event.target;
  if (form.matches && form.matches('[data-variant-form]')) {
    var size = form.querySelector('[name="size"]:checked');
    var color = form.querySelector('[name="color"]:checked');
    var sizeErr = form.querySelector('#size-error');
    var colorErr = form.querySelector('#color-error');
    var ok = true;
    if (form.querySelector('[name="size"]') && !size) {
      if (sizeErr) sizeErr.style.display = 'block';
      ok = false;
    } else {
      if (sizeErr) sizeErr.style.display = 'none';
    }
    if (form.querySelector('[name="color"]') && !color) {
      if (colorErr) colorErr.style.display = 'block';
      ok = false;
    } else {
      if (colorErr) colorErr.style.display = 'none';
    }
    if (!ok) event.preventDefault();
  }
});
document.addEventListener('click', function (event) { const button=event.target.closest('[data-add-cart]'); if(!button)return; button.disabled=true; fetch('cart.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({action:'add',product_id:button.dataset.addCart,size:button.dataset.size||'',color:button.dataset.color||'',quantity:button.dataset.quantity||1})}).then(r=>r.json()).then(data=>{ if(data.success){document.querySelectorAll('.cart-link b').forEach(el=>el.textContent=data.count);button.textContent='Added';} else {window.location='login.php';} }).finally(()=>setTimeout(()=>{button.disabled=false},700)); });
